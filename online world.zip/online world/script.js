document.addEventListener('DOMContentLoaded', () => {
    // Profile picture upload
    const profileUpload = document.getElementById('profile-upload');
    const profilePic = document.getElementById('profile-pic');

    profileUpload.addEventListener('change', (event) => {
        const file = event.target.files[0];
        const formData = new FormData();
        formData.append('profile-pic', file);

        fetch('/upload-profile-pic', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.file) {
                profilePic.src = `/uploads/${data.file}`;
            }
        });
    });

    // Login form submission
    const loginForm = document.getElementById('login');
    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(loginForm);

            fetch('/login', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.message === 'Login successful') {
                    window.location.href = 'profile.html';
                }
            });
        });
    }
});
// Connect to the server via Socket.IO
const socket = io();

// Handle sending a message
const sendButton = document.getElementById('send-button');
const messageInput = document.getElementById('message-input');
const messagesList = document.getElementById('messages');

sendButton.addEventListener('click', () => {
    const message = messageInput.value.trim();
    if (message !== '') {
        // Emit the message to the server
        socket.emit('chatMessage', message);
        messageInput.value = ''; // Clear input after sending
    }
});

// Display incoming messages
socket.on('chatMessage', (message) => {
    const messageElement = document.createElement('li');
    messageElement.textContent = message;
    messagesList.appendChild(messageElement);

    // Scroll to the latest message
    messagesList.scrollTop = messagesList.scrollHeight;
});
