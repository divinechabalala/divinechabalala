const express = require('express');
const multer = require('multer');
const bcrypt = require('bcrypt');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

// Configure file upload storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use(express.urlencoded({ extended: true }));

// Secure session management
app.use(session({
    secret: 'supersecret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true, sameSite: 'Strict' }
}));

// Dummy user data
const users = [
    { username: 'john', passwordHash: bcrypt.hashSync('password123', 10) }
];

// Handle login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);

    if (user) {
        bcrypt.compare(password, user.passwordHash, (err, result) => {
            if (result) {
                req.session.user = user;
                res.json({ message: 'Login successful' });
            } else {
                res.json({ message: 'Incorrect password' });
            }
        });
    } else {
        res.json({ message: 'User not found' });
    }
});

// Handle profile picture upload
app.post('/upload-profile-pic', upload.single('profile-pic'), (req, res) => {
    if (req.file) {
        res.json({ message: 'Profile picture uploaded', file: req.file.filename });
    } else {
        res.status(400).json({ message: 'No file uploaded' });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
const express = require('express');
const multer = require('multer');
const bcrypt = require('bcrypt');
const session = require('express-session');
const path = require('path');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);
const port = 3000;

// Configure file upload storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use(express.urlencoded({ extended: true }));

// Secure session management
app.use(session({
    secret: 'supersecret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true, sameSite: 'Strict' }
}));

// Dummy user data
const users = [
    { username: 'john', passwordHash: bcrypt.hashSync('password123', 10) }
];

// Handle login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);

    if (user) {
        bcrypt.compare(password, user.passwordHash, (err, result) => {
            if (result) {
                req.session.user = user;
                res.json({ message: 'Login successful' });
            } else {
                res.json({ message: 'Incorrect password' });
            }
        });
    } else {
        res.json({ message: 'User not found' });
    }
});

// Handle profile picture upload
app.post('/upload-profile-pic', upload.single('profile-pic'), (req, res) => {
    if (req.file) {
        res.json({ message: 'Profile picture uploaded', file: req.file.filename });
    } else {
        res.status(400).json({ message: 'No file uploaded' });
    }
});

// Real-time chat with Socket.IO
io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('chatMessage', (message) => {
        // Broadcast the message to all users
        io.emit('chatMessage', message);
    });

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
